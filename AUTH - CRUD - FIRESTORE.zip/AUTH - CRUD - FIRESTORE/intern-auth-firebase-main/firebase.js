var firebaseConfig = {
  apiKey: "AIzaSyD2S1gp9aWMxe2k47ODptqQSxCk_uQ6zqI",
  authDomain: "worqhat.firebaseapp.com",
  projectId: "worqhat",
  storageBucket: "worqhat.appspot.com",
  messagingSenderId: "878632594152",
  appId: "1:878632594152:web:b0043ac89b9a590802f75d"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

