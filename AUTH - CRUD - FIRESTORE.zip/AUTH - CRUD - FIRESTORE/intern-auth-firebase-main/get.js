var db = firebase.firestore();

function GetAllDataOnce(){
    db.collection("Patient").get().then((querySnapshot)=>{
        var Patient = [];
        querySnapshot.forEach(doc => {
            Patient.push(doc.data());        
        });
        AddAllItemsToTheTable(Patient);
    });
}

function GetAllDataRealtime(){
    db.collection("Patient").onSnapshot((querySnapshot)=>{
        var Patient = [];
        querySnapshot.forEach(doc => {
            Patient.push(doc.data());        
        });
        AddAllItemsToTheTable(Patient);
    });
}


// filling the table
var stdNo=0;
var tbody = document.getElementById('tbody1');

function AddItemToTable(ID,H_name,H_email,H_address,H_number){
var trow = document.createElement('tr');
var td1 = document.createElement('td');
var td2 = document.createElement('td');
var td3 = document.createElement('td');
var td4 = document.createElement('td');
var td5 = document.createElement('td');
var td6 = document.createElement('td');

td1.innerHTML = ++stdNo;
td2.innerHTML = ID;
td3.innerHTML = H_name;
td4.innerHTML = H_email;
td5.innerHTML = H_address;
td6.innerHTML = H_number;

trow.appendChild(td1);
trow.appendChild(td2);
trow.appendChild(td3);
trow.appendChild(td4);
trow.appendChild(td5);
trow.appendChild(td6);

tbody.appendChild(trow);

}

function AddAllItemsToTheTable(PatientDocsList){
    stdNo=0;
    tbody.innerHTML="";
    PatientDocsList.forEach(element => {
        AddItemToTable(element.ID,element.H_name,element.H_email,element.H_address,element.H_number)
    })
}



window.onload = GetAllDataOnce;